package com.example.myapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

public class CampoGrande extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.tela_campogrande, container, false);
        Button buttonVoltar = view.findViewById(R.id.buttonVoltar);
        buttonVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navegar de volta para o SecondFragment
                NavHostFragment.findNavController(CampoGrande.this)
                        .navigate(R.id.action_telaCampoGrandeFragment_to_SecondFragment);
            }
        });
        Button buttonNacoesIndigenas = view.findViewById(R.id.buttonNacoesIndigenas);
        buttonNacoesIndigenas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Parque das Nações Indigenas");
                builder.setMessage("Esta é a descrição do Parque das Nações Indigenas. O Parque das Nações Indígenas é um parque urbano" +
                        " localizado na cidade de Campo Grande. O local é ideal para quem procura contato com a natureza e tranquilidade," +
                        " e é acessível para todas as idades. O Parque oferece infra-estrutura de lazer e esporte às margens de um lago formado" +
                        " pela nascente do córrego Prosa.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        Button buttonBioparquePantanal = view.findViewById(R.id.buttonBioparquePantanal);
        buttonBioparquePantanal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Bioparque Pantanal");
                builder.setMessage("Esta é a descrição do Bioparque Pantanal. Com 21 mil metros quadrados de área construída, 5 milhões de" +
                        " litros de água e 359 espécies de animais, o espaço conta com 239 tanques (31 de exposições, 1 de abastecimento, 1 de" +
                        " reúso de descarte de efluentes, 38 na quarentena e 168 voltados exclusivamente para a pesquisa, conservação, bioeconomia" +
                        " e sustetabilidade.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        Button buttonMercadaoMunicipal = view.findViewById(R.id.buttonMercadaoMunicipal);
        buttonMercadaoMunicipal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Mercadão Municipal");
                builder.setMessage("Esta é a descrição do Mercadão Municipal. O Mercado Municipal Antônio Valente, mais conhecido como " +
                        "Mercadão, localiza-se em Campo Grande/MS. Área de 2.051,70 m² onde estão distribuidos 214 Bancas e 70 Boxes com " +
                        "variedade de recursos hortifrutigranjeiros e peixes da região, contando também com produtos de qualidade e preços" +
                        " mais acessíveis aos consumidores.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        Button buttonMorada = view.findViewById(R.id.buttonMorada);
        buttonMorada.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Morada dos Baís");
                builder.setMessage("Esta é a descrição da Morada dos Baís. O edifício hoje conhecido como Morada dos Baís " +
                        "foi construído em etapas, entre os anos de 1913 e 1918, para abrigar a família do italiano Bernardo Franco Baís." +
                        "A Morada dos Baís foi tombada pela Prefeitura Municipal de Campo Grande-MS por sua importância cultural para a cidade.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        Button buttonFeiraCG = view.findViewById(R.id.buttonFeiraCG);
        buttonFeiraCG.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Feira Central de Campo Grande");
                builder.setMessage("Esta é a descrição da Feira Central de Campo Grande. A Feira Central de Campo Grande é uma feira localizada " +
                        "na cidade brasileira de Campo Grande, no estado de Mato Grosso do Sul. Também conhecida como feirona, é coordenada pela" +
                        " comunidade okinawana, que já se adaptou à culinária local. É semelhante a uma feira qualquer do Brasil. Os destaques " +
                        "são o tradicional espetinho com a mandioca amarela da terra e o sobá. Outras opções são o artesanato e o comércio de " +
                        "produtos típicos. Em 2017, foi declarada patrimônio cultural e imaterial da cidade.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        return view;
    }
}
