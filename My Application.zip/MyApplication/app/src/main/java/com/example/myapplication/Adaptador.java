package com.example.myapplication;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.Toast;

public class Adaptador extends BaseAdapter {

    /*Essa classe é projetada para ser usada como um adaptador para preencher um componente de interface do usuário,
     como um GridView ou ListView, com imagens representadas por recursos de imagem definidos em um array de inteiros.*/

    private Context ctx;
    private int[] list;

    public Adaptador(Context ctx, int[] list) { //Construtor padrão da Classe
        this.ctx = ctx;
        this.list = list;
    }

    @Override
    public int getCount() { //Método que retorno o número total de itens no conjunto de dados
        return list.length;
    }

    @Override
    public Object getItem(int i) { // retorna o item na posição item 'i' no conjunto de dados
        return list[i];
    }

    @Override
    public long getItemId(int i) { //retorna um identificador único para o item na posição 'i'
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) { /*método é responsável por criar e retornar uma View que representa um item na posição i,
        criando um objeto imageView  configura sua imagem com base no recurso de imagem na posição i e define alguns
        parâmetros de layout, como tamanho e preenchimento*/
        ImageView iv = new ImageView(ctx);
        iv.setImageResource(list[i]);
        iv.setLayoutParams(new ViewGroup.LayoutParams(400,400));
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setPadding(5,5,5,5);
        return iv; // retorna a imageView
    }


}
