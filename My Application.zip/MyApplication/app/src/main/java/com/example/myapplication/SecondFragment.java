package com.example.myapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.myapplication.databinding.FragmentSecondBinding;

import java.util.Arrays;
import java.util.Collections;

public class SecondFragment extends Fragment {

    private boolean ordemAlfabetica = true;

    ListView cidades; /*declara uma variável do tipo ListView que será usada para referenciar o
    componente ListView no layout.*/
    ArrayAdapter<String> adapter;
    /*Declara uma variável adapter do tipo ArrayAdapter<String>, que será usada para preencher o
    ListView com os nomes das cidades.*/
    String[] nomeCidades = {"Aquidauana", "Bodoquena","Bonito",
    "Campo Grande", "Jardim", "Rio Verde"}; //Nome das cidades que serão exibidos nas listas

    private FragmentSecondBinding binding;

    /*No método onCreateView inflamos o layout associado ao fragment e também é inflado o layout do spinner
     que permite ao usuário selecionar a ordenação da lista de cidades*/
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        binding = FragmentSecondBinding.inflate(inflater, container, false);
        View view =  binding.getRoot();

        Spinner spinner = binding.spinner;

        //ArrayAdapter com os itens do Spinner
        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(
                requireContext(), R.array.itens_do_spinner, android.R.layout.simple_spinner_item
        );

        //Layout a ser usado para a exibição do item selecionado
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        //Adaptador associado ao Spinner
        spinner.setAdapter(spinnerAdapter);

        return view;
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //ListView e o adapter são inicializados aqui  para preencher a lista com os nomes das cidades.
        cidades = binding.lvCidades;
        adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, nomeCidades);
        cidades.setAdapter(adapter);
        cidades.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //Configura um ouvinte de clique para os itens
                // da lista para navegar para fragmentos correspondentes quando um item é clicado.
                String itemClicado = nomeCidades[i];

                int destinationId;

                switch (itemClicado) {
                    case "Aquidauana":
                        destinationId = R.id.action_SecondFragment_to_AquidauanaFragment;
                        break;
                    case "Bodoquena":
                        destinationId = R.id.action_SecondFragment_to_BodoquenaFragment;
                        break;
                    case "Bonito":
                        destinationId = R.id.action_SecondFragment_to_BonitoFragment;
                        break;
                    case "Campo Grande":
                        destinationId = R.id.action_SecondFragment_to_CampoGrandeFragment;
                        break;
                    case "Jardim":
                        destinationId = R.id.action_SecondFragment_to_JardimFragment;
                        break;
                    case "Rio Verde":
                        destinationId = R.id.action_SecondFragment_to_RioVerdeFragment;
                        break;
                    default:
                        // Lidar com casos não correspondentes, se necessário
                        destinationId = -1; // Ou outra ação apropriada
                        break;
                }
                if (destinationId != -1) {
                    NavHostFragment.findNavController(SecondFragment.this)
                            .navigate(destinationId);
                }
            }
        });

        //Configura um ouvinte de clique para um botão chamado
        // "buttonSecond" para navegar de volta para o "FirstFragment".
        binding.buttonSecond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(SecondFragment.this)
                        .navigate(R.id.action_SecondFragment_to_FirstFragment);
            }
        });

        //Configura um ouvinte de seleção para o Spinner para permitir ao usuário escolher a ordem
        // de classificação e chama o método ordenarLista() para reordenar a lista conforme a escolha do usuário.
        Spinner spinner = binding.spinner;
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = parent.getItemAtPosition(position).toString();
                if (selectedItem.equals("Ordem Inversa")) {
                    // Se "Ordem Inversa" for selecionado, inverta a ordem dos itens
                    ordemAlfabetica = false;
                    ordenarLista();
                } else {
                    // Caso contrário, use a ordem alfabética padrão
                    ordemAlfabetica = true;
                    ordenarLista();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Nada a fazer aqui
            }
        });
    }
    private void ordenarLista() {
        if (ordemAlfabetica) {
            // Se ordem alfabética, ordene a lista de cidades em ordem alfabética
            Arrays.sort(nomeCidades);
        } else {
            // Se ordem inversa, ordene a lista de cidades em ordem inversa
            Arrays.sort(nomeCidades, Collections.reverseOrder());
        }
        adapter.notifyDataSetChanged(); // Notifique o adaptador para atualizar a exibição
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}