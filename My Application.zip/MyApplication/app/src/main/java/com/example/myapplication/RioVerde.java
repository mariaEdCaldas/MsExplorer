package com.example.myapplication;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

public class RioVerde extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.tela_rio_verde, container, false);
        Button buttonVoltar = view.findViewById(R.id.buttonVoltar);
        buttonVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navegar de volta para o SecondFragment
                NavHostFragment.findNavController(RioVerde.this)
                        .navigate(R.id.action_telaRioVerdeFragment_to_SecondFragment);
            }
        });
        Button buttonFazendaIgrejinha = view.findViewById(R.id.buttonFazendaIgrejinha);
        buttonFazendaIgrejinha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Fazenda Igrejinha");
                builder.setMessage("Esta é a descrição da Fazenda Igrejinha. Uma caminhada de 5 km cruza pelo cerrado e leva a belas " +
                        "formações rochosas e a vistas incríveis da planície do Pantanal, cercado de natureza por todos os lados, dá pra ver o pantanal do " +
                        "alto dos mirantes, com uma trilha é muito boa pra caminhada,");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        Button buttonLagoErnaniJMachado = view.findViewById(R.id.buttonLagoErnaniJMachado);
        buttonLagoErnaniJMachado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Lago Ernani José Machado");
                builder.setMessage("Esta é a descrição do Lago Ernani José Machado. O Lago Ernani José Machado é um lago artificial localizado " +
                        "no município mato-grossense de Lucas do Rio Verde. Foi criado através do represamento do Córrego Lucas com o intuito" +
                        " de transformar o local em um dos principais cartões postais do município.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        Button buttonMatrizNSAuxiliadora = view.findViewById(R.id.buttonMatrizNSAuxiliadora);
        buttonMatrizNSAuxiliadora.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Igreja Matriz Nossa Senhora Auxiliadora");
                builder.setMessage("Esta é a descrição da Igreja Matriz Nossa Senhora Auxiliadora. Em 1910, o fazendeiro Américo de Souza " +
                        "Brito possuía, nesta localidade, uma área de 33.570 hectares, propriedade que se denominava Fazenda Campo Alegre. " +
                        "Em 1913 Américo fez várias doações de terras a destinatários, seus parentes, entre os quais, uma de 1.000 hectares a" +
                        " Antônio Vitorino da Costa. Como proprietário, Antônio fez erguer, em local próximo a atual cidade de Rio Verde, " +
                        "alguns ranchos para outros parentes. Estas foram as primeiras casas de Rio Verde. A igreja foi importante para o " +
                        "Desenvolvimento da cidade de Rio Verde.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        Button buttonSeteQuedas = view.findViewById(R.id.buttonSeteQuedas);
        buttonSeteQuedas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Sete Quedas do Didi");
                builder.setMessage("Esta é a descrição de Sete Quedas do Didi. Há um pouco mais de duas horas e meia de carro de" +
                        " Campo Grande, capital do Mato Grosso do Sul, está Rio Verde, uma cidade que recebe as águas da Bacia do " +
                        "Rio da Prata. E é daí que vem a fama do município. A cidade é praticamente um balneário, com cachoeiras e vários" +
                        "pontos para as pessoas se banharem.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        Button buttonPracaDasAmericas = view.findViewById(R.id.buttonPracaDasAmericas);
        buttonPracaDasAmericas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Praça das Américas");
                builder.setMessage("Esta é a descrição da Praça das Américas. Um ambiente familiar na cidade de Rio Verde no Mato Grosso do Sul," +
                        "conhecida pelo Monumento da Garça, onde uma garça gigante da espaço para um prédio.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        Button buttonPousadaRanchoCawboy = view.findViewById(R.id.buttonPousadaRanchoCawboy);
        buttonPousadaRanchoCawboy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Pousada Rancho do Cowboy");
                builder.setMessage("Esta é a descrição da Pousada Rancho do Cowboy. Com 14 hectares, o lugar fica a 200 metros do" +
                        " rio, que tem 1.50 metros, e uma cachoeira. O acesso pelo rancho é exclusivo para aqueles que pagaram a " +
                        "hospedagem ou o day use. Aqueles que não quiserem ficar no rio podem aproveitar a piscina da propriedade.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        return view;
    }
}
