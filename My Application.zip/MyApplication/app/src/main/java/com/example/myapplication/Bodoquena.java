package com.example.myapplication;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

public class Bodoquena extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.tela_bodoquena, container, false);
        Button buttonVoltar = view.findViewById(R.id.buttonVoltar);
        buttonVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navegar de volta para o SecondFragment
                NavHostFragment.findNavController(Bodoquena.this)
                        .navigate(R.id.action_telaBodoquenaFragment_to_SecondFragment);
            }
        });
        Button buttonBuracoDoMacaco = view.findViewById(R.id.buttonBuracoDoMacaco);
        buttonBuracoDoMacaco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Buraco do Macaco");
                builder.setMessage("Esta é a descrição do Buraco do Macaco. 7 metros de altura, 9 metros de largura e 4 metros de profundidade." +
                        " Formação geológica que proporciona uma grande aventura. Uma gruta formada pela erosão do Córrego da Boca da Onça, " +
                        "com entrada através de um túnel de 5 metros. Você entra a nado pelo túnel e observa a água cair em seu interior.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        Button buttonMorrariaDoSul = view.findViewById(R.id.buttonMorrariaDoSul);
        buttonMorrariaDoSul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Morraria do Sul");
                builder.setMessage("Esta é a descrição da Morraria Do Sul. O mirante de Morraria do Sul, distrito de Bodoquena," +
                        " é um dos locais deslumbrantes do interior de Mato Grosso Sul. Lá de cima, é possível ver a paisagem de parte" +
                        " do Pantanal, sendo cenário popular para fotos.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        Button buttonCachoeiraDoFantasma = view.findViewById(R.id.buttonCachoeiraDoFantasma);
        buttonCachoeiraDoFantasma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Cachoeira do Fantasma");
                builder.setMessage("Esta é a descrição da Cachoeira do Fantasma. São 21 metros de altura formando um enorme véu" +
                        " com um grande volume de água e ao redor muita mata nativa dando ainda mais charme a uma poderosa cachoeira. " +
                        "Algumas das piscinas que se forma na base da cachoeira chegam a 3 metros de profundidade. Uma pequena gruta " +
                        "localizada no meio da cachoeira um dia já foi bem maior e ela está se fechando ao longo dos anos, o mistério é " +
                        "saber até onde ela vai, apesar de ser proibido o acesso a esta cachoeira.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        Button buttonBocaDaOnca = view.findViewById(R.id.buttonBocaDaOnca);
        buttonBocaDaOnca.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Boca da Onça");
                builder.setMessage("Esta é a descrição da Boca da Onça. A cachoeira Boca da Onça é espetacular com seus 156 metros" +
                        " de queda livre. E a mais alta do estado do MS e uma das mais altas do Brasil. O deque de observação, aos pés da " +
                        "cachoeira, possui cadeiras para relaxar e apreciar a água caindo ao alto do paredão do cânion. Um banho refrescante" +
                        " em sua piscina natural, faz parte da experência.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        return view;
    }
}
