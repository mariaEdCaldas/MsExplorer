package com.example.myapplication;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Switch;


import com.example.myapplication.databinding.FragmentGalleryBinding;

public class GalleryFragment extends Fragment {

    private FragmentGalleryBinding binding;
    /*Isso declara uma variável chamada binding do tipo FragmentGalleryBinding,
    que relaciona a vinculação de dados para o layout do fragmento usando o data binding do Android.*/

    public GalleryFragment() { // construtor da classe GalleryFragment

    }

    /* método chamado quando o fragmento é criado e é responsável por inflar o layout associado
    a ele e configurar os componentes da interface do usuário*/
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentGalleryBinding.inflate(inflater, container, false);
        //inflado o layout associado ao fragmento usando o binding
        return binding.getRoot();
        //layout inflado é retornado como a visualização principal do fragmento.


    }
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //Configura um ouvinte de clique para um botão chamado "btnVoltar" que permite ao usuário
        // navegar de volta para o fragmento "FirstFragment".
        binding.btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(GalleryFragment.this)
                        .navigate(R.id.action_ThirdFragment_to_FirstFragment);
            }
        });
        //Cria um array de recursos de imagens imageResources, que contém os
        // IDs das imagens que serão exibidas na galeria.
        int[] imageResources = new int[] {
                R.drawable.balneario_municipal_bonito, R.drawable.bioparque_pantanal, R.drawable.boca_da_onca,
                R.drawable.buraco_das_araras, R.drawable.buraco_do_macaco, R.drawable.cachoeira_do_fantasma,
                R.drawable.catedral_jardim_ms, R.drawable.cemiterio_dos_herois, R.drawable.fazenda_igrejinha,
                R.drawable.feira_central, R.drawable.gruta_catedral, R.drawable.gruta_lago_azul,
                R.drawable.igreja_matriz_nossa_senhora_auxiliadora, R.drawable.igreja_n_s_imaculada,
                R.drawable.jardim_ecopark, R.drawable.lago_ernani_jose_machado,
                R.drawable.lagoa_misteriosa, R.drawable.mercadao_municipal, R.drawable.morada_dos_bais,
                R.drawable.morraria_do_sul, R.drawable.morro_paxixi, R.drawable.museu_arte_pantaneira,
                R.drawable.museu_cer3, R.drawable.museu_marechal_jose_machado_lopes, R.drawable.nacoes_indigenas,
                R.drawable.parquelagoacomprida, R.drawable.pousada_rancho_do_cawboy, R.drawable.praca_das_americas,
                R.drawable.recanto_ecologico_rio_da_prata, R.drawable.rio_sucuri,R.drawable.sala_exposicao_retirada_da_laguna,
                R.drawable.sete_quedas_do_didi
        };
        //Configura um adaptador personalizado chamado Adaptador (definido na classe Adaptador)
        // para o GridView chamado "gridViewGallery" e preenche-o com as imagens do imageResources.
        binding.gridViewGallery.setAdapter(new Adaptador(getContext(),imageResources));
        binding.gridViewGallery.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            //Configura um ouvinte de clique para os itens do GridView para exibir informações sobre a
            // imagem selecionada no TextView chamado "imgTxtView".
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i) {
                    case 0:
                        binding.imgTxtView.setText("Balneário Municipal de Bonito - Bonito MS");
                        break;
                    case 1:
                        binding.imgTxtView.setText("Bioparque Pantanal - Campo Grande MS");
                        break;
                    case 2:
                        binding.imgTxtView.setText("Boca da Onça - Bodoquena MS");
                        break;
                    case 3:
                        binding.imgTxtView.setText("Buraco das Araras - Jardim MS");
                        break;
                    case 4:
                        binding.imgTxtView.setText("Buraco do Macaco - Bodoquena MS");
                        break;
                    case 5:
                        binding.imgTxtView.setText("Cachoeira do Fantasma - Bodoquena MS");
                        break;
                    case 6:
                        binding.imgTxtView.setText("Catedral de Nossa Senhora de Fátima - Jardim MS");
                        break;
                    case 7:
                        binding.imgTxtView.setText("Cemitério dos Heróis - Jardim MS");
                        break;
                    case 8:
                        binding.imgTxtView.setText("Fazenda Igrejinha - Rio Verde MS");
                        break;
                    case 9:
                        binding.imgTxtView.setText("Feira Central - Campo Grande MS");
                        break;
                    case 10:
                        binding.imgTxtView.setText("Gruta Catedral - Bonito MS");
                        break;
                    case 11:
                        binding.imgTxtView.setText("Gruta Lago Azul - Bonito MS");
                        break;
                    case 12:
                        binding.imgTxtView.setText("Igreja Matriz Nossa Senhora Auxiliadora - Rio Verde MS");
                        break;
                    case 13:
                        binding.imgTxtView.setText("Igreja Nossa Senhora Imaculada Conceição - Aquidauana MS");
                        break;
                    case 14:
                        binding.imgTxtView.setText("Jardim EcoPark - Jardim MS");
                        break;
                    case 15:
                        binding.imgTxtView.setText("Lago Ernani José Machado - Rio Verde MS");
                        break;
                    case 16:
                        binding.imgTxtView.setText("Lagoa Misteriosa - Bonito MS");
                        break;
                    case 17:
                        binding.imgTxtView.setText("Mercadão Municipal - Campo Grande MS");
                        break;
                    case 18:
                        binding.imgTxtView.setText("Morada dos Bais - Campo Grande MS");
                        break;
                    case 19:
                        binding.imgTxtView.setText("Morraria do Sul - Bodoquena MS");
                        break;
                    case 20:
                        binding.imgTxtView.setText("Morro Paxixi - Aquidauana MS");
                        break;
                    case 21:
                        binding.imgTxtView.setText("Museu da Arte Pantaneira - Aquidauana MS");
                        break;
                    case 22:
                        binding.imgTxtView.setText("Museu CER3 - Jardim MS");
                        break;
                    case 23:
                        binding.imgTxtView.setText("Museu Marechal Josè Machado Lopes - Aquidauana MS");
                        break;
                    case 24:
                        binding.imgTxtView.setText("Parque das Nações Indigenas - Campo Grande MS");
                        break;
                    case 25:
                        binding.imgTxtView.setText("Parque Lagoa Comprida - Aquidauana MS");
                        break;
                    case 26:
                        binding.imgTxtView.setText("Pousada Rancho do Cowboy - Rio Verde MS");
                        break;
                    case 27:
                        binding.imgTxtView.setText("Praça das Américas - Rio Verde MS");
                        break;
                    case 28:
                        binding.imgTxtView.setText("Recanto Ecológico do Rio da Prata - Bonito MS");
                        break;
                    case 29:
                        binding.imgTxtView.setText("Rio Sucuri - Bonito MS");
                        break;
                    case 30:
                        binding.imgTxtView.setText("Sala de Exposição Retirada da Laguna - Jardim MS");
                        break;
                    case 31:
                        binding.imgTxtView.setText("Balneário Sete Quedas do Didi - Rio Verde MS");
                        break;
                }
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}