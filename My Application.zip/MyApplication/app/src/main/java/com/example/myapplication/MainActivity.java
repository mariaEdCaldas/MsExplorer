package com.example.myapplication;


import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.AppBarConfiguration;

import com.example.myapplication.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private MediaPlayer mediaPlayer; //Inicializa o objeto MediaPlayer que será usado para o som do aplicativo
    private NavController navController; //Utiliza o NavController para facilitar a navegação entra fragmentos
    private boolean isPlaying = true; //Variavel true quando a musica do aplicativo está tocando
    private ActivityMainBinding binding; // Declaração do ViewBinding

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Inicializa o ViewBinding
        binding = ActivityMainBinding.inflate(getLayoutInflater()); //Infla o layout da activity
        setContentView(binding.getRoot()); //Define o layout como conteúdo da activity

        //Define um ouvinte de clique para o iconeOpcoesButton, quando clicado, chama a
        // função showPopupMenu(v) para exibir o menu popUp
        ImageView iconeOpcoesButton = binding.iconeOpcoes;
        iconeOpcoesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopupMenu(v);
            }
        });

        // Usa o NavHostFragment para obter o navController
        NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager()
                .findFragmentById(R.id.nav_host_fragment);
        navController = navHostFragment.getNavController();

        // Inicializa o MediaPlayer e carrega o arquivo de áudio
        mediaPlayer = MediaPlayer.create(this, R.raw.nature_media); // Substitua "sua_musica" pelo nome do arquivo de áudio sem a extensão

        // Inicia a reprodução da música do aplicativo
        mediaPlayer.start();
    }

    /* essa função é chamada quando o ícone de opções é clicado.
    Ela cria e exibe um menu pop-up com base em um arquivo de menu definido em R.menu.menu_main (menu_main.xml)*/
    private void showPopupMenu(View view) {
        PopupMenu popupMenu = new PopupMenu(this, view);
        popupMenu.getMenuInflater().inflate(R.menu.menu_main, popupMenu.getMenu());

        //Configura um ouvinte para o item do Menu PopUp
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                //No caso desse menu, só há uma opção, que é a ligar/desligar o som do app
                int itemId = item.getItemId();
                if (itemId == R.id.action_settings) {
                    toggleSound();
                    return true;
                }
                return false;
            }
        });

        popupMenu.show();
    }

    /*A função toggleSound() é responsável por alternar entre a pausa e a reprodução do áudio. Se a música
     estiver tocando (ou seja, o estado atual é "isPlaying" é verdadeiro), a função pausa a música.
      Caso contrário, inicia a reprodução da música. O estado de reprodução é alternado invertendo o
       valor da variável isPlaying.*/
    private void toggleSound() {
        if (isPlaying) {
            // Se estiver tocando, pause a música
            if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                mediaPlayer.pause();
            }
        } else {
            // Se não estiver tocando, inicie a reprodução da música
            if (mediaPlayer != null) {
                mediaPlayer.start();
            }
        }
        isPlaying = !isPlaying; // Alterne o estado de reprodução
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        // Libera os recursos do MediaPlayer quando a atividade for destruída
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}
