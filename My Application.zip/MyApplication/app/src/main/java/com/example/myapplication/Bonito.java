package com.example.myapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

public class Bonito extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.tela_bonito, container, false);
        Button buttonVoltar = view.findViewById(R.id.buttonVoltar);
        buttonVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navegar de volta para o SecondFragment
                NavHostFragment.findNavController(Bonito.this)
                        .navigate(R.id.action_telaBonitoFragment_to_SecondFragment);
            }
        });
        Button buttonGrutaCatedral = view.findViewById(R.id.buttonGrutaCatedral);
        buttonGrutaCatedral.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Gruta Catedral");
                builder.setMessage("Esta é a descrição da Gruta Catedral. A Gruta Catedral (antiga Gruta de São Mateus) é uma caverna que" +
                        " foi descoberta na década de 1940 e por muitos anos teve como proprietário Mateus Muller. Um fato curioso é que seu" +
                        " antigo nome foi uma singela homenagem ao próprio Mateus. Localizada bem pertinho do centro de Bonito MS, a apenas 4" +
                        " quilômetros, ela está em uma propriedade de 50 hectares, sendo 49 deles de mata nativa preservada.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        Button buttonGrutaLagoAzul = view.findViewById(R.id.buttonGrutaLagoAzul);
        buttonGrutaLagoAzul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Gruta Lago Azul");
                builder.setMessage("Esta é a descrição da Gruta Lago Azul. A Gruta do Lago Azul é o maior cartão-postal de Bonito," +
                        " no Mato Grosso do Sul, e um dos passeios mais famosos e procurados pelos visitantes de todo o Brasil. Toda a entrada da " +
                        "gruta é lapidada por rochas e, para descer, é preciso usar a escadaria íngreme de mais ou menos 300 degraus, equivalente" +
                        " a 150 metros de altura.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        Button buttonRioSucuri = view.findViewById(R.id.buttonRioSucuri);
        buttonRioSucuri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Rio Sucuri");
                builder.setMessage("Esta é a descrição do Rio Sucuri. O Rio Sucuri, localizado em Bonito/MS, possui uma das águas mais cristalinas" +
                        " em todo o mundo e por isso encanta as pessoas que têm a oportunidade de conhecê-lo. Além disso, o local oferece diferentes" +
                        " opções de passeios e é um ponto turístico imperdível para quem visita a região.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        Button buttonLagoaMisteriosa = view.findViewById(R.id.buttonLagoaMisteriosa);
        buttonLagoaMisteriosa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Lagoa Misteriosa");
                builder.setMessage("Esta é a descrição da Lagoa Misteriosa. A Lagoa Misteriosa é uma das mais incríveis atrações naturais" +
                        " do destino Bonito, em Mato Grosso do Sul. A dolina de águas incrivelmente transparentes e profundidade abismal " +
                        "é local de flutuação com snorkel e mergulho com cilindro. É, sem dúvida, uma experiência surreal e inesquecível.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        Button buttonRioDaPrata = view.findViewById(R.id.buttonRioDaPrata);
        buttonRioDaPrata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Recanto Ecológico do Rio da Prata");
                builder.setMessage("Esta é a descrição do Recanto Ecológico do Rio da Prata. O Recanto Ecológico Rio da Prata é uma enorme " +
                        "fazenda que oferece uma série de atividades para seus visitantes como trilha, flutuação, mergulho com cilindro, " +
                        "passeio a cavalo e observação de aves.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        return view;
    }
}
