package com.example.myapplication;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

public class Jardim extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.tela_jardim, container, false);
        Button buttonVoltar = view.findViewById(R.id.buttonVoltar);
        buttonVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navegar de volta para o SecondFragment
                NavHostFragment.findNavController(Jardim.this)
                        .navigate(R.id.action_telaJardimFragment_to_SecondFragment);
            }
        });
        Button buttonBuracoDasAraras = view.findViewById(R.id.buttonBuracoDasAraras);
        buttonBuracoDasAraras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Buraco das Araras");
                builder.setMessage("Esta é a descrição do Buraco das Araras. O  Buraco das Araras é uma das maiores dolinas do mundo," +
                        " com aproximadamente 100 metros de profundidade e 500 metros de circunferência, localizada no município de Jardim-MS.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        Button buttonJardimEcoPark = view.findViewById(R.id.buttonJardimEcoPark);
        buttonJardimEcoPark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Jardim Eco Park");
                builder.setMessage("Esta é a descrição do Jardim Eco Park. Uma área maravilhosa de contato com a natureza, " +
                        "as margens do Rio da Prata, que possui águas cristalinas e rica biodiversidade de peixes, aves e outros animais.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        Button buttonCemiterioDosHerois = view.findViewById(R.id.buttonCemiterioDosHerois);
        buttonCemiterioDosHerois.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Cemitério dos Heróis");
                builder.setMessage("Esta é a descrição do Cemitério dos Heróis. O Cemitério dos Heróis é um Patrimônio histórico do Município de " +
                        "Jardim no estado de Mato Grosso do Sul. Foi na margem esquerda do Rio Miranda que morreram e foram enterrados heróis " +
                        "nacionais, no episódio da Retirada da Laguna, como o coronel Carlos de Morais Camisão, o tenente-coronel Juvêncio Cabral " +
                        "de Menezes e o José Francisco Lopes, o Guia Lopes.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        Button buttonRetiradaDaLaguna = view.findViewById(R.id.buttonRetiradaDaLaguna);
        buttonRetiradaDaLaguna.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Sala de Exposição da Retirada da Laguna");
                builder.setMessage("Esta é a descrição da Sala de Exposição da Retirada da Laguna. Idealizada pelo General de Exército Lourival" +
                        " Carvalho Silva, esta sala de exposição se constitui em mais um importante passo na missão de homenagear os heróis da" +
                        " Retirada da Laguna. Uma missão que teve início logo após a guerra, em 1874, quando o Imperador D. Pedro II mandou construir" +
                        " um monumento no local onde alguns desses heróis tombaram, no parque histórico hoje conhecido como Cemitério dos Heróis.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        Button buttonMuseuCER3 = view.findViewById(R.id.buttonMuseuCER3);
        buttonMuseuCER3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Museu CER3");
                builder.setMessage("Esta é a descrição do Museu CER3. O museu CER-3 foi criado pelos militares e ex-funcionários da CER-3, " +
                        "uma organização militar do tempo da construção da rodovia. O acervo do museu conta com equipamentos antigos, objetos," +
                        " fotos, relatos e documentos que fizeram parte da história da região.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        Button buttonCatedralJardim = view.findViewById(R.id.buttonCatedralJardim);
        buttonCatedralJardim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Catedral Nossa Senhora de Fátima");
                builder.setMessage("Esta é a descrição da Catedral Nossa Senhora de Fátima. Interessante por tratar-se da nossa representação" +
                        " máxima no que concerne à igreja católica Apostólica Romana que representa. Importante por tratar-se de obra e produto" +
                        " da igreja Católica Apostólica Romana.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        return view;
    }
}
