package com.example.myapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

public class Aquidauana extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.tela_aquidauana, container, false);
        Button buttonVoltar = view.findViewById(R.id.buttonVoltar);
        buttonVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navegar de volta para o SecondFragment
                NavHostFragment.findNavController(Aquidauana.this)
                        .navigate(R.id.action_telaAquidauanaFragment_to_SecondFragment);
            }

        });
        Button buttonArtePantaneira = view.findViewById(R.id.buttonArtePantaneira);
        buttonArtePantaneira.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Museu da Arte Pantaneira");
                builder.setMessage("Esta é a descrição do Museu da Arte Pantaneira. Construído em 1918, o imóvel já foi ocupado pela " +
                        "Caixa Econômica Federal, Asilo dos Idosos, Escola Padre Anchieta e Secretaria de Obras. A inauguração do Museu " +
                        "aconteceu em 1999, mas foi em 2002 que ganhou o nome de Museu de Arte Pantaneira Manoel Antonio Paes de Barros em " +
                        "homenagem a um dos fundadores da cidade de Aquidauana.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        Button buttonMarechalJoseMachado = view.findViewById(R.id.buttonMarechalJoseMachado);
        buttonMarechalJoseMachado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Museu José Machado Lopes");
                builder.setMessage("Esta é a descrição do Museu José Machado Lopes. Criado em 1962, o Museu Marechal José Machado Lopes " +
                        "fica no 9º Batalhão de Engenharia de Combate, na Rua Duque de Caxias, S/N, no Bairro Alto. O nome do museu homenageia " +
                        "o então Coronel Machado Lopes, que comandou a unidade do Exército na Segunda Guerra Mundial (1939-1945).");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        Button buttonLagoaComprida = view.findViewById(R.id.buttonLagoaComprida);
        buttonLagoaComprida.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Parque Lagoa Comprida");
                builder.setMessage("Esta é a descrição do Parque Lagoa Comprida. Com uma extensa área verde e uma grande lagoa, o Parque" +
                        " já apresenta as características do ecossistema do Pantanal. Possui pista iluminada para caminhadas, quadra de areia" +
                        " e o Viveiro Municipal. É uma importante área de preservação e de contato com o meio ambiente.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        Button buttonMorroPaxixi = view.findViewById(R.id.buttonMorroPaxixi);
        buttonMorroPaxixi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Morro do Paxixi");
                builder.setMessage("Esta é a descrição do Morro do Paxixi. Localizado a cerca de 150 quilômetros de Campo Grande, no distrito de " +
                        "Camisão, pertencente a Aquidauana, com uma altitude de 700 metros, é um destino popular para quem busca aventura e contato" +
                        " com a natureza.De fácil acesso, é possível chegar a base do topo de carro de passeio" +
                        " ou motocicleta. De lá em alguns minutos de caminhada o visitante poderá contemplar a vista de um dos mirantes do morro.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        Button buttonNSImaculada = view.findViewById(R.id.buttonNSImaculada);
        buttonNSImaculada.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exibir um AlertDialog com a descrição do lugar
                AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                builder.setTitle("Igreja da Nossa Senhora Imaculada Conceição");
                builder.setMessage("Esta é a descrição da Igreja da Nossa Senhora Imaculada Conceição. Um templo majestoso e de presença marcante" +
                        " e onipotente. Duas torres, como agulhas fincam o céu. Um prédio de coloração clara parece guardar Aquidauana. " +
                        "Os visitantes que chegam a nossa cidade vislumbram com tanta beleza a Igreja Matriz Nossa Senhora da Imaculada Conceição. " +
                        "O que muitos não sabem, é que por trás dessa arquitetura encantadora, há uma história centenária.");
                builder.setPositiveButton("OK", null); // Botão "OK" para fechar o AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        return view;
    }
}
